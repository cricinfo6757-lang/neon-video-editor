package com.neon.videoeditor

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

@UnstableApi
class MainActivity : ComponentActivity() {
    private val cyan = Color.rgb(0,229,255)
    private val muted = Color.rgb(160,180,195)
    private lateinit var player: ExoPlayer
    private lateinit var playerView: PlayerView
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var start: EditText
    private lateinit var end: EditText
    private lateinit var backgroundToggle: CheckBox
    private lateinit var voiceToggle: CheckBox
    private lateinit var gain: SeekBar
    private lateinit var gainText: TextView
    private lateinit var colorSpinner: Spinner
    private lateinit var backgroundInfo: TextView
    private lateinit var save: Button
    private lateinit var cancel: Button
    private lateinit var progress: ProgressBar
    private val controls = mutableListOf<View>()
    private val worker = Executors.newSingleThreadExecutor()
    private lateinit var engine: EditorEngine
    private var input: Uri? = null
    private var duration = 0L
    private var bg: Bitmap? = null
    private var output: File? = null
    private var busy = false
    private var destroying = false
    private val colors = intArrayOf(Color.rgb(15,25,45),Color.WHITE,Color.BLACK,
        Color.rgb(0,190,100),Color.rgb(20,100,220))

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if(uri != null) importVideo(uri)
    }
    private val pickBackground = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if(uri != null) importBackground(uri)
    }
    private val saveVideo = registerForActivityResult(ActivityResultContracts.CreateDocument("video/mp4")) { uri ->
        if(uri != null) saveOutput(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        player = ExoPlayer.Builder(this).build()
        engine = EditorEngine(applicationContext)
        buildUi()
        status.text = "Import a short video. AI cutout works on people, not arbitrary objects."
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.BLACK); isFillViewport=true }
        root = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(dp(18),dp(32),dp(18),dp(36))
        }
        scroll.addView(root)
        label("NEON VIDEO EDITOR",24f,cyan)
        label("Person cutout • Custom background • Voice filters • MP4",13f,muted)
        action("Import video") { pickVideo.launch(arrayOf("video/*")) }
        playerView=PlayerView(this).apply { player=this@MainActivity.player; useController=true }
        root.addView(playerView,LinearLayout.LayoutParams(-1,dp(240)))
        label("Trim start (seconds)")
        start=timeField("0")
        label("Trim end (seconds)")
        end=timeField("")
        label("Maximum selected duration: 60 seconds. Background exports: 24 fps, longest side ≤640 px.",12f,muted)
        backgroundToggle=CheckBox(this).apply {
            text="Remove person background"; setTextColor(Color.WHITE); isChecked=true
        }
        addControl(backgroundToggle)
        action("Choose custom background image") { pickBackground.launch(arrayOf("image/*")) }
        backgroundInfo=label("No image selected; the selected color will be used.",12f,muted)
        action("Remove selected background image") {
            bg?.recycle(); bg=null
            backgroundInfo.text="No image selected; the selected color will be used."
        }
        label("Background color (used when no image is selected)")
        colorSpinner=Spinner(this).apply {
            adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,
                arrayOf("Dark blue","White","Black","Green","Blue"))
        }
        addControl(colorSpinner)
        voiceToggle=CheckBox(this).apply {
            text="Voice cleanup: rumble filter + soft gate + compressor"
            setTextColor(Color.WHITE); isChecked=true
        }
        addControl(voiceToggle)
        label("Voice cleanup is basic DSP, NOT AI denoise or music/vocal separation.",12f,muted)
        gainText=label("Output gain: 100%",14f,cyan)
        gain=SeekBar(this).apply { max=150; progress=100 }
        gain.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?,p:Int,fromUser:Boolean) { gainText.text="Output gain: $p%" }
            override fun onStartTrackingTouch(s:SeekBar?) {}
            override fun onStopTrackingTouch(s:SeekBar?) {}
        })
        addControl(gain)
        action("Preview original video") {
            val uri=input
            if(uri==null) message("Import a video first.")
            else { player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.play()
                message("Original preview. Use Export to apply effects and view the edited result.") }
        }
        action("Apply effects and export MP4") { export() }
        progress=ProgressBar(this).apply { visibility=View.GONE }
        root.addView(progress)
        cancel=Button(this).apply {
            text="Cancel export"; visibility=View.GONE
            setOnClickListener {
                engine.cancel(); message("Cancelling…")
                // Do not start another task while the renderer is still unwinding.
                // A new Activity instance creates a fresh engine and worker.
                finish()
            }
        }
        root.addView(cancel)
        save=Button(this).apply {
            text="Save edited MP4…"; isEnabled=false
            setOnClickListener {
                if(output?.exists()==true) saveVideo.launch("Neon_Edit_${System.currentTimeMillis()}.mp4")
            }
        }
        root.addView(save)
        status=label("",14f,cyan)
        label("Keep this screen open during export. Cancel closes the editor; re-open it to start again. Original files are never overwritten.",12f,muted)
        setContentView(scroll)
    }

    private fun persist(uri:Uri) {
        try { contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        catch(_:Exception) {}
    }

    private fun importVideo(uri:Uri) {
        persist(uri); setBusy(true,false); message("Reading video…")
        worker.execute {
            var millis=0L; var error:String?=null
            val reader=MediaMetadataRetriever()
            try {
                reader.setDataSource(this,uri)
                millis=reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()?:0
                require(millis>0) { "Cannot read video duration." }
                require(reader.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO)=="yes") {
                    "No readable video track."
                }
            } catch(e:Exception) { error=e.message }
            finally { reader.release() }
            runOnUiThread {
                if(destroying) return@runOnUiThread
                setBusy(false)
                if(error!=null) { message("Import failed: $error"); return@runOnUiThread }
                input=uri; duration=millis
                start.setText("0")
                end.setText(String.format(Locale.US,"%.3f",minOf(60_000L,duration)/1000.0))
                player.setMediaItem(MediaItem.fromUri(uri)); player.prepare()
                message("Imported. Duration: ${String.format(Locale.US,"%.2f",duration/1000.0)} seconds.")
            }
        }
    }

    private fun importBackground(uri:Uri) {
        setBusy(true,false); message("Reading background image…")
        worker.execute {
            var image:Bitmap?=null; var error:String?=null
            try {
                val source=ImageDecoder.createSource(contentResolver,uri)
                image=ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
                    decoder.allocator=ImageDecoder.ALLOCATOR_SOFTWARE
                    val scale=minOf(1.0,1280.0/maxOf(info.size.width,info.size.height))
                    decoder.setTargetSize(maxOf(1,(info.size.width*scale).toInt()),
                        maxOf(1,(info.size.height*scale).toInt()))
                }
            } catch(e:Exception) { error=e.message }
            runOnUiThread {
                if(destroying) { image?.recycle(); return@runOnUiThread }
                setBusy(false)
                if(error!=null) { message("Image failed: $error"); return@runOnUiThread }
                bg?.recycle(); bg=image
                backgroundInfo.text="Custom image ready: ${image?.width} × ${image?.height}"
                backgroundToggle.isChecked=true
                message("Custom background selected.")
            }
        }
    }

    private fun export() {
        if(busy) return
        val uri=input ?: return message("Import a video first.")
        val a=start.text.toString().toDoubleOrNull()
        val b=end.text.toString().toDoubleOrNull()
        if(a==null || b==null || !a.isFinite() || !b.isFinite() || a<0 || b<=a ||
            b>duration/1000.0+0.005 || b-a>60.005 || b-a<0.2) {
            message("Use valid times within the video, with a selected duration of 0.2–60 seconds.")
            return
        }
        val from=(a*1000).toLong()
        val until=minOf(duration,(b*1000).toLong())
        player.pause()
        setBusy(true,true)
        engine.start(EditorEngine.Options(uri,from,until,backgroundToggle.isChecked,bg,
            colors[colorSpinner.selectedItemPosition],voiceToggle.isChecked,gain.progress/100f),
            status={ if(!destroying) message(it) },
            done={ file,error ->
                if(destroying) { file?.delete() }
                else {
                    setBusy(false)
                    if(file==null) message("Export failed: $error")
                    else {
                        output?.delete(); output=file
                        save.isEnabled=true
                        player.setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
                        player.prepare(); player.play()
                        message("Edited video ready. Preview above; tap Save edited MP4 to keep it.")
                    }
                }
            })
    }

    private fun saveOutput(uri:Uri) {
        val file=output ?: return
        setBusy(true,false); message("Saving…")
        worker.execute {
            var error:String?=null
            try {
                file.inputStream().use { source ->
                    val stream=contentResolver.openOutputStream(uri,"w") ?: error("Cannot open save destination.")
                    stream.use { target -> source.copyTo(target); target.flush() }
                }
            } catch(e:Exception) { error=e.message }
            runOnUiThread {
                if(destroying) return@runOnUiThread
                setBusy(false)
                message(if(error==null) "Saved successfully." else "Save failed: $error. Retry saving.")
            }
        }
    }

    private fun setBusy(value:Boolean, exporting:Boolean=false) {
        busy=value
        controls.forEach { it.isEnabled=!value }
        save.isEnabled=!value && output?.exists()==true
        cancel.visibility=if(value && exporting) View.VISIBLE else View.GONE
        progress.visibility=if(value) View.VISIBLE else View.GONE
        if(value) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }
    private fun message(value:String) { status.text=value }
    private fun addControl(view:View) { controls.add(view); root.addView(view) }
    private fun label(text:String,size:Float=14f,color:Int=muted):TextView {
        val view=TextView(this).apply {
            this.text=text; textSize=size; setTextColor(color)
            setPadding(0,dp(10),0,dp(10))
        }
        root.addView(view); return view
    }
    private fun action(title:String,block:()->Unit) {
        addControl(Button(this).apply {
            text=title; isAllCaps=false; setTextColor(cyan)
            minHeight=dp(50); setOnClickListener { block() }
        })
    }
    private fun timeField(initial:String):EditText {
        val view=EditText(this).apply {
            setText(initial); setTextColor(Color.WHITE); setSingleLine(true)
            inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        addControl(view); return view
    }
    private fun dp(n:Int)=(n*resources.displayMetrics.density).toInt()
    override fun onStop() { super.onStop(); player.pause() }
    override fun onDestroy() {
        destroying=true
        engine.close()
        playerView.player=null; player.release()
        worker.shutdown()
        // Cached exports are left for Android to reclaim; saved copies remain untouched.
        super.onDestroy()
    }
}
