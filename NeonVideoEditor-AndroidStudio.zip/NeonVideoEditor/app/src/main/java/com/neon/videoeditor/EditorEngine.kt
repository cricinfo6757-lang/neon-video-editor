package com.neon.videoeditor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.ceil

@UnstableApi
class EditorEngine(private val context: Context) {
    data class Options(val uri: Uri, val startMs: Long, val endMs: Long,
        val replaceBackground: Boolean, val background: Bitmap?, val color: Int,
        val cleanupVoice: Boolean, val gain: Float)

    @Volatile private var cancelled = false
    private var transformer: Transformer? = null
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var polling: Runnable? = null
    private var temporary: File? = null
    private var closed = false

    fun start(options: Options, status: (String) -> Unit, done: (File?, String?) -> Unit) {
        check(Looper.myLooper() == Looper.getMainLooper())
        check(!closed)
        cancelled = false
        val pre = File(context.cacheDir,"prepared_${System.nanoTime()}.mp4")
        temporary = pre
        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(options.startMs).setEndPositionMs(options.endMs).build()
        val processors = listOf<AudioProcessor>(VoiceProcessor(options.cleanupVoice,options.gain))
        val edited = EditedMediaItem.Builder(MediaItem.Builder().setUri(options.uri)
            .setClippingConfiguration(clipping).build())
            .setEffects(Effects(processors, emptyList())).build()
        try {
            val instance = Transformer.Builder(context)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        stopPolling(); transformer = null
                        if(cancelled || closed) { pre.delete(); return }
                        if(!options.replaceBackground) {
                            temporary = null; done(pre,null); return
                        }
                        status("Stage 2: removing background…")
                        worker.execute {
                            var output: File? = null
                            var error: String? = null
                            try { output = render(pre, options, status) }
                            catch(t: Exception) { error = t.message ?: "Background export failed." }
                            finally { pre.delete() }
                            val result = output
                            val message = error
                            main.post {
                                temporary = null
                                if(closed || cancelled) result?.delete()
                                else done(result,message)
                            }
                        }
                    }
                    override fun onError(composition: Composition, exportResult: ExportResult,
                        exportException: ExportException) {
                        stopPolling(); transformer = null
                        pre.delete(); temporary = null
                        if(!closed && !cancelled) done(null,exportException.message ?: "Preparation failed.")
                    }
                }).build()
            transformer = instance
            status("Stage 1: preparing trim and audio…")
            instance.start(edited,pre.absolutePath)
            polling = object : Runnable {
                override fun run() {
                    val t = transformer ?: return
                    val p = ProgressHolder()
                    if(t.getProgress(p) == Transformer.PROGRESS_STATE_AVAILABLE)
                        status("Stage 1: preparing trim/audio ${p.progress}%")
                    main.postDelayed(this,500)
                }
            }
            main.post(polling!!)
        } catch(t: Exception) {
            transformer?.cancel(); transformer = null; stopPolling()
            pre.delete(); temporary = null
            done(null,t.message ?: "Could not start export.")
        }
    }

    private fun render(prepared: File, options: Options, status: (String) -> Unit): File {
        val output = File(context.cacheDir,"edited_${System.nanoTime()}.mp4")
        val retriever = MediaMetadataRetriever()
        var backgroundCopy: Bitmap? = null
        try {
            check(!cancelled)
            retriever.setDataSource(prepared.absolutePath)
            val duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                ?.toLongOrNull() ?: error("Cannot read prepared duration.")
            val first = retriever.getFrameAtTime(0,MediaMetadataRetriever.OPTION_CLOSEST)
                ?: error("Cannot decode video frame.")
            val factor = minOf(1.0,640.0/maxOf(first.width,first.height))
            val width = maxOf(2,((first.width*factor).toInt()/2)*2)
            val height = maxOf(2,((first.height*factor).toInt()/2)*2)
            first.recycle()
            // Private copy avoids sharing mutable bitmap state with UI.
            backgroundCopy = options.background?.copy(Bitmap.Config.ARGB_8888,false)
            val canvasBitmap = Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888)
            val frameCanvas = Canvas(canvasBitmap)
            val paint = Paint(Paint.FILTER_BITMAP_FLAG)
            val target = Rect(0,0,width,height)
            try {
                PersonRenderer(width,height,backgroundCopy,options.color).use { renderer ->
                    BitmapVideoEncoder(output,width,height,24,prepared).use { encoder ->
                        val count = ceil(duration*24.0/1000.0).toInt()
                        require(count > 0)
                        for (index in 0 until count) {
                            check(!cancelled) { "Cancelled." }
                            val pts = index * 1_000_000L / 24
                            val raw = retriever.getScaledFrameAtTime(pts,
                                MediaMetadataRetriever.OPTION_CLOSEST,width,height)
                                ?: error("Failed to decode frame $index.")
                            frameCanvas.drawBitmap(raw,null,target,paint)
                            raw.recycle()
                            encoder.frame(renderer.render(canvasBitmap),pts)
                            if(index % 6 == 0 || index == count-1) {
                                val percent = (index+1)*100/count
                                main.post { if(!closed && !cancelled)
                                    status("Stage 2: background replacement $percent%") }
                            }
                        }
                        check(!cancelled) { "Cancelled." }
                        encoder.finish { cancelled }
                    }
                }
            } finally { canvasBitmap.recycle() }
            require(output.exists() && output.length()>0) { "Output is empty." }
            return output
        } catch(t: Exception) {
            output.delete(); throw t
        } finally {
            backgroundCopy?.recycle()
            retriever.release()
        }
    }

    private fun stopPolling() { polling?.let { main.removeCallbacks(it) }; polling = null }

    fun cancel() {
        cancelled = true
        stopPolling()
        val active = transformer
        if(active != null) {
            active.cancel(); transformer = null
            temporary?.delete(); temporary = null
        }
    }

    fun close() {
        closed = true; cancel(); worker.shutdown()
    }
}
