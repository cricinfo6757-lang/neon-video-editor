package com.neon.videoeditor

import android.graphics.Bitmap
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.opengl.EGL14
import android.opengl.EGLExt
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.opengl.GLUtils
import android.view.Surface
import java.io.Closeable
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Surface-input H.264 encoder. Receives opaque, upright RGB bitmaps. */
class BitmapVideoEncoder(
    output: File, private val width: Int, private val height: Int,
    private val fps: Int, audioSource: File
) : Closeable {
    private var codec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var inputSurface: Surface? = null
    private var display: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var context: EGLContext = EGL14.EGL_NO_CONTEXT
    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var program = 0
    private var texture = 0
    private var videoTrack = -1
    private var audioTrack = -1
    private var started = false
    private var finished = false
    private var extractor: MediaExtractor? = null
    private val info = MediaCodec.BufferInfo()
    private val vertices = ByteBuffer.allocateDirect(16 * 4)
        .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
            put(floatArrayOf(-1f,-1f,0f,1f, 1f,-1f,1f,1f,
                -1f,1f,0f,0f, 1f,1f,1f,0f)); position(0)
        }

    init {
        try {
            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            extractor = MediaExtractor().apply { setDataSource(audioSource.absolutePath) }
            val source = extractor!!
            for (i in 0 until source.trackCount) {
                val format = source.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME).orEmpty()
                if (mime.startsWith("audio/")) {
                    require(mime == MediaFormat.MIMETYPE_AUDIO_AAC) {
                        "Prepared audio must be AAC."
                    }
                    source.selectTrack(i)
                    audioTrack = muxer!!.addTrack(format)
                    break
                }
            }
            codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height)
            format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            format.setInteger(MediaFormat.KEY_BIT_RATE, 2_500_000)
            format.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            format.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            codec!!.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = codec!!.createInputSurface()
            setupEgl(inputSurface!!)
            codec!!.start()
            setupGl()
        } catch (t: Throwable) {
            close()
            throw t
        }
    }

    private fun setupEgl(surface: Surface) {
        display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        check(display != EGL14.EGL_NO_DISPLAY) { "No EGL display." }
        val versions = IntArray(2)
        check(EGL14.eglInitialize(display, versions, 0, versions, 1))
        val configs = arrayOfNulls<EGLConfig>(1)
        val count = IntArray(1)
        val attributes = intArrayOf(
            EGL14.EGL_RED_SIZE,8, EGL14.EGL_GREEN_SIZE,8,
            EGL14.EGL_BLUE_SIZE,8, EGL14.EGL_ALPHA_SIZE,8,
            EGL14.EGL_RENDERABLE_TYPE,EGL14.EGL_OPENGL_ES2_BIT,
            EGL14.EGL_SURFACE_TYPE,EGL14.EGL_WINDOW_BIT,
            0x3142,1, EGL14.EGL_NONE
        )
        check(EGL14.eglChooseConfig(display, attributes, 0, configs, 0, 1, count, 0)
            && count[0] > 0) { "No recordable EGL config." }
        val config = configs[0]!!
        context = EGL14.eglCreateContext(display, config, EGL14.EGL_NO_CONTEXT,
            intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION,2,EGL14.EGL_NONE),0)
        check(context != EGL14.EGL_NO_CONTEXT)
        eglSurface = EGL14.eglCreateWindowSurface(display, config, surface,
            intArrayOf(EGL14.EGL_NONE),0)
        check(eglSurface != EGL14.EGL_NO_SURFACE)
        check(EGL14.eglMakeCurrent(display, eglSurface, eglSurface, context))
    }

    private fun shader(type: Int, source: String): Int {
        val shader = GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader, source)
        GLES20.glCompileShader(shader)
        val ok = IntArray(1)
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, ok, 0)
        check(ok[0] != 0) { GLES20.glGetShaderInfoLog(shader) }
        return shader
    }

    private fun setupGl() {
        val vertex = shader(GLES20.GL_VERTEX_SHADER,
            "attribute vec2 aPos; attribute vec2 aUv; varying vec2 uv; " +
                "void main(){gl_Position=vec4(aPos,0.0,1.0);uv=aUv;}")
        val fragment = shader(GLES20.GL_FRAGMENT_SHADER,
            "precision mediump float; varying vec2 uv; uniform sampler2D image; " +
                "void main(){gl_FragColor=texture2D(image,uv);}")
        program = GLES20.glCreateProgram()
        GLES20.glAttachShader(program, vertex); GLES20.glAttachShader(program, fragment)
        GLES20.glLinkProgram(program)
        val ok = IntArray(1)
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, ok, 0)
        check(ok[0] != 0) { GLES20.glGetProgramInfoLog(program) }
        GLES20.glDeleteShader(vertex); GLES20.glDeleteShader(fragment)
        val textures = IntArray(1)
        GLES20.glGenTextures(1, textures, 0)
        texture = textures[0]
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
    }

    fun frame(bitmap: Bitmap, presentationTimeUs: Long) {
        check(!finished)
        drain(false)
        GLES20.glViewport(0,0,width,height)
        GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D,0,bitmap,0)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(program,"image"),0)
        val pos = GLES20.glGetAttribLocation(program,"aPos")
        val uv = GLES20.glGetAttribLocation(program,"aUv")
        vertices.position(0)
        GLES20.glVertexAttribPointer(pos,2,GLES20.GL_FLOAT,false,16,vertices)
        GLES20.glEnableVertexAttribArray(pos)
        vertices.position(2)
        GLES20.glVertexAttribPointer(uv,2,GLES20.GL_FLOAT,false,16,vertices)
        GLES20.glEnableVertexAttribArray(uv)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4)
        check(GLES20.glGetError() == GLES20.GL_NO_ERROR) { "OpenGL frame error." }
        EGLExt.eglPresentationTimeANDROID(display,eglSurface,presentationTimeUs*1000L)
        check(EGL14.eglSwapBuffers(display,eglSurface)) { "Encoder surface failure." }
        drain(false)
    }

    private fun drain(end: Boolean) {
        val encoder = codec!!
        val deadline = System.nanoTime() + 30_000_000_000L
        while (true) {
            val index = encoder.dequeueOutputBuffer(info, if(end) 10_000L else 0L)
            when {
                index == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!end) return
                    check(System.nanoTime() < deadline) { "Encoder timed out." }
                }
                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    check(!started) { "Encoder format changed twice." }
                    videoTrack = muxer!!.addTrack(encoder.outputFormat)
                    muxer!!.start(); started = true
                }
                index >= 0 -> {
                    val buffer = encoder.getOutputBuffer(index)!!
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (info.size > 0) {
                        check(started)
                        buffer.position(info.offset); buffer.limit(info.offset+info.size)
                        muxer!!.writeSampleData(videoTrack, buffer, info)
                    }
                    val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                    encoder.releaseOutputBuffer(index,false)
                    if (eos) return
                }
            }
        }
    }

    fun finish(cancelled: () -> Boolean) {
        codec!!.signalEndOfInputStream()
        drain(true)
        if (audioTrack >= 0) {
            val source = extractor!!
            val buffer = ByteBuffer.allocateDirect(2 * 1024 * 1024)
            val audioInfo = MediaCodec.BufferInfo()
            while (true) {
                check(!cancelled()) { "Cancelled." }
                buffer.clear()
                val size = source.readSampleData(buffer,0)
                if (size < 0) break
                check(size <= buffer.capacity()) { "Audio packet too large." }
                val pts = source.sampleTime
                if (pts >= 0) {
                    audioInfo.set(0,size,pts,source.sampleFlags)
                    buffer.position(0); buffer.limit(size)
                    muxer!!.writeSampleData(audioTrack,buffer,audioInfo)
                }
                source.advance()
            }
        }
        check(started) { "No video frames were encoded." }
        muxer!!.stop(); started = false; finished = true
    }

    override fun close() {
        if (display != EGL14.EGL_NO_DISPLAY) {
            if (context != EGL14.EGL_NO_CONTEXT) {
                try {
                    if (program != 0) GLES20.glDeleteProgram(program)
                    if (texture != 0) GLES20.glDeleteTextures(1,intArrayOf(texture),0)
                } catch (_: Exception) {}
            }
            EGL14.eglMakeCurrent(display,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_CONTEXT)
            if (eglSurface != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display,eglSurface)
            if (context != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display,context)
            EGL14.eglReleaseThread(); EGL14.eglTerminate(display)
            display = EGL14.EGL_NO_DISPLAY
        }
        try { codec?.stop() } catch (_: Exception) {}
        try { codec?.release() } catch (_: Exception) {}
        codec = null
        inputSurface?.release(); inputSurface = null
        try { if(started) muxer?.stop() } catch (_: Exception) {}
        try { muxer?.release() } catch (_: Exception) {}
        muxer = null
        extractor?.release(); extractor = null
    }
}
