package com.neon.videoeditor

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sign

/** Offline speech-focused filters, not a neural denoiser. */
@UnstableApi
class VoiceProcessor(private val cleanup: Boolean, private val gain: Float) : BaseAudioProcessor() {
    private var channels = 0
    private var sampleRate = 48000
    private var oldInput = FloatArray(0)
    private var high = FloatArray(0)
    private var low = FloatArray(0)
    private var envelope = FloatArray(0)
    private var sampleIndex = 0L

    override fun onConfigure(format: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (format.encoding != C.ENCODING_PCM_16BIT) {
            throw AudioProcessor.UnhandledAudioFormatException(format)
        }
        channels = format.channelCount
        sampleRate = format.sampleRate
        oldInput = FloatArray(channels)
        high = FloatArray(channels)
        low = FloatArray(channels)
        envelope = FloatArray(channels)
        return format
    }

    override fun onFlush() {
        oldInput.fill(0f); high.fill(0f); low.fill(0f); envelope.fill(0f)
        sampleIndex = 0
    }

    override fun queueInput(input: ByteBuffer) {
        val output = replaceOutputBuffer(input.remaining())
        val highAlpha = exp(-2.0 * Math.PI * 90.0 / sampleRate).toFloat()
        val lowAlpha = (1.0 - exp(-2.0 * Math.PI * 6500.0 / sampleRate)).toFloat()
        while (input.remaining() >= 2) {
            val channel = (sampleIndex % channels).toInt()
            var value = input.short / 32768f
            if (cleanup) {
                val hp = highAlpha * (high[channel] + value - oldInput[channel])
                oldInput[channel] = value
                high[channel] = hp
                low[channel] += lowAlpha * (hp - low[channel])
                value = low[channel]
                val magnitude = abs(value)
                val smoothing = if (magnitude > envelope[channel]) 0.15f else 0.0015f
                envelope[channel] += smoothing * (magnitude - envelope[channel])
                val gate = (envelope[channel] / 0.012f).coerceIn(0.15f, 1f)
                value *= gate
                if (abs(value) > 0.25f) {
                    value = sign(value) * 0.25f * (abs(value) / 0.25f).pow(0.5f)
                }
                value *= 1.35f
            }
            value = (value * gain).coerceIn(-0.98f, 0.98f)
            output.putShort((value * 32767f).toInt().toShort())
            sampleIndex++
        }
        output.flip()
    }
}
