package com.neon.videoeditor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import java.io.Closeable
import java.util.concurrent.TimeUnit

/** Processes one video frame at a time on the export worker. */
class PersonRenderer(
    private val width: Int,
    private val height: Int,
    background: Bitmap?,
    color: Int
) : Closeable {
    private val segmenter = Segmentation.getClient(
        SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .build()
    )
    private val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    private val subject = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    private val backdrop = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    private val canvas = Canvas(output)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val pixels = IntArray(width * height)

    init {
        val bgCanvas = Canvas(backdrop)
        bgCanvas.drawColor(color)
        if (background != null) {
            val scale = maxOf(width.toFloat() / background.width, height.toFloat() / background.height)
            val matrix = Matrix().apply {
                setScale(scale, scale)
                postTranslate((width - background.width * scale) / 2f,
                    (height - background.height * scale) / 2f)
            }
            bgCanvas.drawBitmap(background, matrix, paint)
        }
    }

    fun render(frame: Bitmap): Bitmap {
        require(frame.width == width && frame.height == height)
        val mask = Tasks.await(
            segmenter.process(InputImage.fromBitmap(frame, 0)),
            60, TimeUnit.SECONDS
        )
        require(mask.width == width && mask.height == height) {
            "Segmentation returned an unexpected mask size."
        }
        val confidence = mask.buffer
        confidence.rewind()
        frame.getPixels(pixels, 0, width, 0, 0, width, height)
        for (i in pixels.indices) {
            val probability = confidence.float
            val t = ((probability - 0.20f) / 0.65f).coerceIn(0f, 1f)
            val smooth = t * t * (3f - 2f * t)
            val alpha = (smooth * 255f).toInt()
            pixels[i] = (pixels[i] and 0x00ffffff) or (alpha shl 24)
        }
        subject.setPixels(pixels, 0, width, 0, 0, width, height)
        canvas.drawColor(Color.BLACK)
        canvas.drawBitmap(backdrop, 0f, 0f, paint)
        canvas.drawBitmap(subject, 0f, 0f, paint)
        return output
    }

    override fun close() {
        segmenter.close()
        output.recycle(); subject.recycle(); backdrop.recycle()
    }
}
