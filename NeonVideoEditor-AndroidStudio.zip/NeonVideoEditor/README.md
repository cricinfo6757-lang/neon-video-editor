# Neon Video Editor — Android Studio source

## What is implemented
- Import a local video using the system document picker.
- Preview original video, trim selected range (0.2 to 60 seconds).
- ML Kit person segmentation applied frame-by-frame to the exported video.
- Custom image background or selected opaque color (center-crop).
- Basic speech DSP: 90 Hz high-pass, 6.5 kHz low-pass, soft noise gate,
  compressor, gain, and output limiting. This is NOT neural denoising.
- MP4 export: H.264 video and AAC audio, edited-output preview, save picker.
- Cancel, error display, sequential bounded-memory frame processing.

## Scope and limits — read before building
This is a complete source implementation of a SMALL, foreground editor, not a
CapCut replacement. It has NOT been compiled, installed or benchmarked by the
assistant. There is no zero-bug or device-compatibility guarantee.

Minimum Android 9 (API 28). Background replacement outputs constant 24 fps with
the longest side at most 640 px. Selected clip length is limited to 60 seconds.
This deliberately prioritizes bounded memory and understandable implementation,
not production-grade throughput. Frame extraction plus CPU compositing can be
very slow, especially for long-GOP/4K video. Test 5–10 seconds first.

Segmentation is for PEOPLE, not arbitrary objects. Hair, hands, motion blur,
multiple people, and low contrast may show halos, flicker or missing detail.
No transparent-alpha MP4 export: cutout is composited onto an image/color.
Background image is static, not animated/video. Effects are rendered during
export; the initial preview is the ORIGINAL video. The finished edited output
is previewed automatically. Per-frame extraction resamples to 24 fps, so a
variable-frame-rate source can have repeated/dropped frames.

Input audio is processed in a Media3 preparation pass and encoded to AAC;
the second pass copies that prepared AAC track to the replacement video.
Silent videos stay silent. Short AAC padding / 24-fps rounding may create a
small ending-duration difference. This is not an exact sample/frame editor.

Keep the app open during export. There is no foreground service, process-death
recovery or resumable job. Rotation is handled without recreating the Activity.
Cancellation closes the editor; reopening starts a fresh session. Android can
still terminate the app. Original inputs are not modified. Save the output
using the save button before leaving; unsaved cached files may be reclaimed.
No Firebase, backend, ads or API keys are required.

## Build
Recommended reproducible toolchain:
- JDK 17 (Gradle JDK)
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- Kotlin 2.0.21
- Android SDK platform 35, minimum device API 28

The ZIP contains all handwritten project source, but NOT the binary Gradle
wrapper JAR, Android SDK, dependency caches, signing keys or a prebuilt APK.

Easiest import:
1. Install Android Studio and SDK platform 35.
2. Create an Empty Views Activity project (Kotlin, package
   com.neon.videoeditor, minimum SDK 28; NOT Compose).
3. Close that project. Copy this ZIP's settings.gradle.kts, build.gradle.kts,
   gradle.properties and app/ over the generated project. Remove the template's
   old MainActivity if it uses a different package. Retain generated gradlew,
   gradlew.bat and gradle/wrapper/.
4. In gradle/wrapper/gradle-wrapper.properties set distributionUrl to:
   https\://services.gradle.org/distributions/gradle-8.9-bin.zip
5. Set Android Studio Gradle JDK to 17. Sync. Internet is needed for dependencies.
6. Run on a physical API 28+ Android device. Test standard SDR MP4 first.
7. To build a shareable APK use Build > Generate Signed App Bundle / APK > APK.
   Create your own keystore and keep it private/backed up. Never share passwords.

Alternatively, install Gradle 8.9 and run `gradle wrapper --gradle-version 8.9`
in the extracted project, then open it in Android Studio and sync.

## Testing checklist (not claimed executed)
- Import landscape and portrait MP4; check upright output and correct colors.
- Use a 5-second talking-person clip with a static photo background.
- Export with background replacement on; compare saved output to original.
- Repeat with color only, then replacement off.
- Check trim boundaries and audio/video sync, including nonzero start time.
- Compare voice cleanup on/off and 0%,100%,150% gain; judge artifacts.
- Test silent video, unsupported/corrupt file, denied file access, cancelled picker.
- Test cancelling stage 1 and stage 2, then reopen the app.
- Test saving to Downloads, low space and unavailable destination providers.
- Test rotation, leaving the app, and memory pressure (no recovery guarantee).

## Source layout
MainActivity.kt — UI, document pickers, settings, preview and save.
EditorEngine.kt — preparation, frame extraction and export orchestration.
PersonRenderer.kt — ML Kit confidence mask and photo/color compositing.
BitmapVideoEncoder.kt — EGL/MediaCodec H.264 encoding and AAC muxing.
VoiceProcessor.kt — offline PCM speech-focused DSP.
